<template>
  <farm-main :paddingTop="['xl', 'xxl']" :paddingX="['m', 'xl', 'xxl']">
    <app-bar-options :title="$t('Login')"/>
    
    <!-- SSO Token Check -->
    <div v-if="!ssoChecked" class="status-text">
      <icon-spinner/>
      <farm-text>Checking for existing authentication...</farm-text>
    </div>
    
    <!-- SSO Failed Message -->
    <div v-else-if="ssoChecked && !ssoAvailable" class="status-text">
      <farm-text>
        For seamless login, please first authenticate through the admin system:
        <a href="https://admin.soilsync.shop/admin/login" target="_blank">Login to Admin</a>
      </farm-text>
      <br><br>
      <farm-text>Or enter your farmOS credentials below:</farm-text>
    </div>
    
    <!-- Login Form -->
    <div v-if="ssoChecked">
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">https://</span>
        </div>
        <input
          v-model="url"
          :placeholder="$t('Enter your farmOS URL')"
          autofocus
          type="url"
          autocomplete="url"
          class="form-control"
          v-on:input="checkValues"
        >
      </div>
      <br>
      <div class="input-group">
        <input
          v-model="username"
          :placeholder="$t('Enter your username')"
          type="text"
          autocomplete="username"
          class="form-control"
          v-on:input="checkValues"
        >
      </div>
      <br>
      <div class="input-group">
        <input
          v-model="password"
          :placeholder="$t('Enter your password')"
          type="password"
          autocomplete="current-password"
          class="form-control"
          v-on:input="checkValues"
        >
      </div>
      <br>
      <div class="input-group login-submit">
        <button
          v-if="!authPending && !updatesPending"
          :disabled="!this.valuesEntered"
          title="Submit credentials"
          @click="submitCredentials"
          class="btn btn-success btn-navbar"
          type="button"
        >
          {{ $t('Submit credentials')}}
        </button>
      </div>
      <br>
      <div class="status-text">
        <farm-text v-if="!authPending && !updatesPending">
          {{ $t('Need a server? Check out')}}
          <a href="https://farmos.org/hosting/">{{ $t('hosting options')}}</a>.
        </farm-text>
        <icon-spinner v-if="authPending || updatesPending"/>
        <farm-text v-if="authPending">Authorizing...</farm-text>
        <farm-text v-if="updatesPending">Authorization successful!</farm-text>
        <farm-text v-if="updatesPending">Updating farm and user configuration...</farm-text>
      </div>
    </div>
  </farm-main>
</template>

<script>
import { refreshCache } from '../idb/cache';
import {
  clientId, getHost, getToken, setHost, setToken,
} from '../farm/remote';
import farm from '../farm';
import { updateFieldModules } from '../field-modules';
import { updateConfigDocs } from '../entities/configDocuments';
import { updateProfile } from '../farm/profile';

export default {
  name: 'LoginScreen',
  data() {
    return {
      valuesEntered: false,
      authPending: false,
      updatesPending: false,
      username: '',
      password: '',
      url: '',
      ssoChecked: false,
      ssoAvailable: false,
    };
  },
  inject: ['alert'],
  methods: {
    async checkSSOTokens() {
      try {
        // Check for pre-authenticated farmOS tokens from SSO
        const response = await fetch('https://admin.soilsync.shop/sso/farmos-tokens', {
          method: 'GET',
          credentials: 'include', // Include cookies for session
          headers: {
            'Accept': 'application/json',
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          
          // Store the pre-authenticated tokens
          setHost(data.host);
          setToken(data.token);
          
          // Set up farm remote with the tokens
          const remote = {
            host: data.host,
            clientId,
            getToken,
            setToken,
          };
          farm.remote.add(remote);
          
          // Update configuration and redirect to home
          this.updatesPending = true;
          
          try {
            await Promise.race([
              Promise.all([
                updateConfigDocs(),
                updateProfile(),
                updateFieldModules(),
                refreshCache(),
              ]),
              new Promise((_, reject) => 
                setTimeout(() => reject(new Error('Update timeout')), 10000)
              )
            ]);
          } catch (updateError) {
            console.warn('SSO update process had issues, continuing anyway:', updateError);
            // Continue to home page even if updates fail
          }
          
          this.updatesPending = false;
          this.$router.push('/home');
          return true;
        } else {
          // SSO failed - check the response
          const errorData = await response.json().catch(() => ({}));
          console.log('SSO check failed:', response.status, errorData);
          
          if (response.status === 401 || response.status === 403) {
            // User not authenticated in admin system
            this.ssoAvailable = false;
          }
        }
      } catch (error) {
        console.log('SSO token check failed, showing login form:', error);
        this.ssoAvailable = false;
      }
      
      this.ssoChecked = true;
      return false;
    },
    checkValues() {
      const urlIsValid = process.env.NODE_ENV === 'development' || this.url !== '';
      const usernameIsValid = this.username !== '';
      const passwordIsValid = this.password !== '';
      if (urlIsValid && usernameIsValid && passwordIsValid) {
        this.valuesEntered = true;
      }
    },
    submitCredentials() {
      this.authPending = true;
      const host = process.env.NODE_ENV === 'development'
        ? '' : `https://${this.url.replace(/(^\w+:|^)\/\//, '')}`;
      const remote = {
        host, clientId, getToken, setToken,
      };
      setHost(host);
      farm.remote.add(remote);
      return farm.remote.authorize(this.username, this.password)
        .then(() => {
          this.updatesPending = true;
          this.authPending = false;
          return updateConfigDocs()
            .then(updateProfile)
            .then(updateFieldModules)
            .then(refreshCache)
            .then(() => {
              this.updatesPending = false;
              this.$router.push('/home');
            });
        })
        .catch((e) => {
          this.authPending = false;
          this.updatesPending = false;
          this.alert(e);
        });
    },
  },
  async created() {
    // First check for SSO tokens
    const hasSSOTokens = await this.checkSSOTokens();
    if (!hasSSOTokens) {
      // If no SSO tokens, show the login form
      this.url = getHost()?.replace(/(^\w+:|^)\/\//, '') || '';
    }
  },
};

</script>

<style scoped>

 .login-submit {
   justify-content: center;
 }
 .status-text {
   text-align: center;
 }

</style>
